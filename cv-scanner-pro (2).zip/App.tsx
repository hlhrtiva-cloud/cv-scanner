import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { PainPoints } from './components/PainPoints';
import { Solution } from './components/Solution';
import { Features } from './components/Features';
import { Pricing } from './components/Pricing';
import { Comparison } from './components/Comparison';
import { HowItWorks } from './components/HowItWorks';
import { CtaFinal } from './components/CtaFinal';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans">
      <Navbar />
      <main>
        <Hero />
        <PainPoints />
        <Solution />
        <Features />
        <Comparison />
        <Pricing />
        <HowItWorks />
        <CtaFinal />
      </main>
      <Footer />
    </div>
  );
};

export default App;