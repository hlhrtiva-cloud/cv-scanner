import React from 'react';
import { 
  Bot, CheckSquare, Mail, PieChart, Users, 
  Search, Calendar, Bell, Shield 
} from 'lucide-react';

const FeatureCard = ({ title, icon, children }: { title: string, icon: React.ReactNode, children?: React.ReactNode }) => (
  <div className="flex flex-col gap-4 p-6 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
    <div className="flex items-center gap-3 mb-2">
      <div className="p-3 bg-primary-50 rounded-lg text-primary-700">
        {icon}
      </div>
      <h3 className="text-lg font-bold text-slate-900 leading-tight">{title}</h3>
    </div>
    <div className="text-slate-600 text-sm space-y-3 leading-relaxed">
      {children}
    </div>
  </div>
);

export const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary-700 font-bold tracking-wide uppercase text-sm">Công nghệ cốt lõi</span>
          <h2 className="mt-2 text-3xl font-bold text-slate-900">Tính năng Vượt trội - Vận hành Đơn giản</h2>
          <p className="mt-4 text-slate-600 max-w-2xl mx-auto">Tích hợp sức mạnh của Google AI vào quy trình làm việc hàng ngày của bạn.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <FeatureCard title="AI SÀNG LỌC & ĐÁNH GIÁ" icon={<Bot size={24} />}>
            <p><strong>Công nghệ:</strong> Google AI mới nhất. Phân tích ngữ nghĩa chuyên sâu.</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Trích xuất dữ liệu ứng viên tự động (Họ tên, Email...).</li>
              <li>Đánh giá năng lực dựa trên bảng mô tả công việc (JD).</li>
              <li>Xếp hạng ứng viên theo thang điểm 1-5 sao.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="XÉT DUYỆT CV 1 CHẠM" icon={<CheckSquare size={24} />}>
            <p>Kết nối HR và Sếp (Hiring Manager) siêu tốc:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>HR gửi hồ sơ chọn lọc cho Quản lý chỉ với 1 click.</li>
              <li>Quản lý xem và bấm <strong>"Duyệt" / "Loại" ngay trong Email</strong> (Không cần đăng nhập phần mềm).</li>
              <li>Kết quả tự động cập nhật về Google Sheets của HR.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="EMAIL MARKETING TỰ ĐỘNG" icon={<Mail size={24} />}>
            <p>Hệ thống CRM thu nhỏ cho tuyển dụng:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Cá nhân hóa nội dung email (Tên, Vị trí).</li>
              <li>Gửi hàng loạt thư mời phỏng vấn.</li>
              <li>Theo dõi trạng thái gửi thành công.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="DASHBOARD TRỰC QUAN" icon={<PieChart size={24} />}>
            <p>Báo cáo quản trị thời gian thực:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Theo dõi phễu tuyển dụng (Funnel) tức thì.</li>
              <li>Đo lường thời gian tuyển dụng trung bình.</li>
              <li>Xuất báo cáo PDF chuyên nghiệp cho Ban giám đốc.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="KHO ỨNG VIÊN (TALENT POOL)" icon={<Users size={24} />}>
            <p>Xây dựng nguồn dữ liệu nội bộ:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Lưu trữ hồ sơ tập trung, bảo mật.</li>
              <li>Phân loại ứng viên theo thẻ (Tags), kỹ năng.</li>
              <li>Tìm kiếm ứng viên cũ cho vị trí mới dễ dàng.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="TỰ ĐỘNG SO KHỚP (MATCHING)" icon={<Search size={24} />}>
            <p>So khớp thông minh:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Tự động so sánh kỹ năng trong CV với yêu cầu công việc.</li>
              <li>Tính toán độ phù hợp (%) khách quan.</li>
              <li>Giảm thiểu thiên kiến chủ quan trong tuyển dụng.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="TÍCH HỢP LỊCH PHỎNG VẤN" icon={<Calendar size={24} />}>
            <p>Đồng bộ Google Calendar:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Tự động tạo sự kiện lịch khi mời phỏng vấn.</li>
              <li>Gửi thư mời (.ics) cho ứng viên và người phỏng vấn.</li>
              <li>Nhắc lịch tự động tránh quên lịch.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="THÔNG BÁO THÔNG MINH" icon={<Bell size={24} />}>
            <p>Không bỏ lỡ thông tin quan trọng:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Thông báo khi có ứng viên tiềm năng cao.</li>
              <li>Cảnh báo hạn xử lý hồ sơ.</li>
              <li>Thông báo khi quản lý đã phê duyệt.</li>
            </ul>
          </FeatureCard>

          <FeatureCard title="AN TOÀN DỮ LIỆU" icon={<Shield size={24} />}>
            <p>Chuẩn bảo mật Doanh nghiệp:</p>
            <ul className="list-disc pl-4 space-y-2 mt-2">
              <li>Dữ liệu nằm hoàn toàn trên Cloud của bạn.</li>
              <li>Không chia sẻ dữ liệu với bên thứ 3.</li>
              <li>Tuân thủ các quy định bảo mật doanh nghiệp.</li>
            </ul>
          </FeatureCard>
        </div>
      </div>
    </section>
  );
};