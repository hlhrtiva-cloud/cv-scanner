import React from 'react';
import { Check, X, HelpCircle, Star } from 'lucide-react';

export const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-16 sm:py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-4xl font-bold text-slate-900 leading-tight">Chi phí linh hoạt - Hiệu quả tối đa</h2>
          <p className="mt-4 text-slate-600 text-base sm:text-lg">Đầu tư nhỏ - Lợi ích lớn cho Doanh nghiệp SME</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto items-center">
          
          {/* Plan 1: Free */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8 order-2 lg:order-1 h-fit">
            <h3 className="text-lg font-bold text-slate-900 mb-2 uppercase tracking-wide">Trải nghiệm</h3>
            <div className="text-3xl sm:text-4xl font-extrabold text-slate-900 mb-4">0 VNĐ</div>
            <p className="text-slate-500 mb-6 sm:mb-8 text-sm h-auto sm:h-10">Dành cho cá nhân muốn kiểm thử tính năng sản phẩm.</p>
            
            <a href="https://docs.google.com/spreadsheets/d/1X7cGtQU3sLYn5Qf5gXKxnREHXX_cgQWf_t6oFbgITQs/edit?gid=1780097193#gid=1780097193" target="_blank" rel="noopener noreferrer" className="block w-full py-3 px-6 text-center rounded-lg border-2 border-slate-200 text-slate-700 font-bold hover:border-primary-600 hover:text-primary-600 transition-all mb-6 sm:mb-8 active:bg-slate-50">
              Copy Template
            </a>

            <div className="space-y-4 text-sm">
              <div className="flex items-center gap-3"><Check className="w-5 h-5 text-green-500 shrink-0" /><span>20 CVs miễn phí</span></div>
              <div className="flex items-center gap-3"><Check className="w-5 h-5 text-green-500 shrink-0" /><span>AI chấm điểm cơ bản</span></div>
              <div className="flex items-center gap-3 opacity-50"><X className="w-5 h-5 text-slate-400 shrink-0" /><span>Không hỗ trợ kỹ thuật</span></div>
            </div>
          </div>

          {/* Plan 2: Yearly (Best Value) */}
          <div className="bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 p-6 sm:p-8 order-1 lg:order-2 relative transform lg:scale-105 z-10">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-yellow-400 to-yellow-600 text-slate-900 text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-lg">
              <Star size={12} className="fill-slate-900" /> Khuyên dùng
            </div>
            <h3 className="text-lg font-bold text-white mb-2 uppercase tracking-wide">Gói Năm</h3>
            <div className="text-4xl sm:text-5xl font-extrabold text-white mb-2">2,499k</div>
            <div className="text-slate-400 mb-4 font-medium">/ năm</div>
            <p className="text-slate-300 mb-6 sm:mb-8 text-sm h-auto sm:h-10">Tối ưu chi phí dài hạn. Cam kết cập nhật tính năng liên tục.</p>
            
            <a href="https://zalo.me/0961128912" target="_blank" rel="noopener noreferrer" className="block w-full py-4 px-6 text-center rounded-lg bg-primary-600 text-white font-bold hover:bg-primary-700 transition-all shadow-lg hover:shadow-primary-600/50 mb-6 sm:mb-8 active:scale-95">
              Liên hệ đăng ký
            </a>

            <div className="space-y-4 text-sm text-slate-300">
               <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-400 shrink-0" /><span className="text-white font-bold">Tiết kiệm 30% so với tháng</span></div>
               <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-400 shrink-0" /><span>1,500 CVs / tháng</span></div>
               <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-400 shrink-0" /><span>Full tính năng PRO</span></div>
               <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-400 shrink-0" /><span>Ưu tiên hỗ trợ 1-1</span></div>
               <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-400 shrink-0" /><span>Setup hệ thống miễn phí</span></div>
            </div>
          </div>

          {/* Plan 3: Monthly */}
          <div className="bg-white rounded-2xl shadow-sm border border-primary-100 p-6 sm:p-8 order-3 h-fit">
            <h3 className="text-lg font-bold text-primary-700 mb-2 uppercase tracking-wide">Gói Tháng</h3>
            <div className="text-3xl sm:text-4xl font-extrabold text-slate-900 mb-4">299k</div>
            <div className="text-slate-500 mb-4 font-medium">/ tháng</div>
            <p className="text-slate-500 mb-6 sm:mb-8 text-sm h-auto sm:h-10">Linh hoạt, phù hợp cho nhu cầu tuyển dụng thời vụ.</p>
            
            <a href="https://zalo.me/0961128912" target="_blank" rel="noopener noreferrer" className="block w-full py-3 px-6 text-center rounded-lg bg-white border-2 border-primary-600 text-primary-700 font-bold hover:bg-primary-50 transition-all mb-6 sm:mb-8 active:bg-slate-50">
              Đăng ký tháng
            </a>

            <div className="space-y-4 text-sm">
              <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-600 shrink-0" /><span>1,500 CVs / tháng</span></div>
              <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-600 shrink-0" /><span>Email Tự động</span></div>
              <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-600 shrink-0" /><span>Dashboard nâng cao</span></div>
              <div className="flex items-center gap-3"><Check className="w-5 h-5 text-primary-600 shrink-0" /><span>Hỗ trợ tiêu chuẩn</span></div>
            </div>
          </div>

        </div>
        
        {/* Support Note */}
        <div className="mt-12 sm:mt-16 text-center">
            <p className="text-slate-600 flex flex-col sm:flex-row items-center justify-center gap-2 text-sm sm:text-base">
                <span className="flex items-center gap-2"><HelpCircle size={18} /> Cần gói Enterprise tùy chỉnh cho tập đoàn?</span>
                <a href="https://zalo.me/0961128912" className="text-primary-700 font-bold hover:underline">Liên hệ Zalo: 096 112 8912</a>
            </p>
        </div>

      </div>
    </section>
  );
};