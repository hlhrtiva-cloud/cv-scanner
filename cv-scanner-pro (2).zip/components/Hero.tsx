import React from 'react';
import { CheckCircle, Shield, Database, Layout, ArrowRight, Star } from 'lucide-react';

export const Hero: React.FC = () => {
  const demoLink = "https://docs.google.com/spreadsheets/d/1X7cGtQU3sLYn5Qf5gXKxnREHXX_cgQWf_t6oFbgITQs/edit?gid=1780097193#gid=1780097193";
  const embedLink = "https://docs.google.com/spreadsheets/d/1X7cGtQU3sLYn5Qf5gXKxnREHXX_cgQWf_t6oFbgITQs/preview?gid=1780097193";

  return (
    <div className="relative pt-24 pb-16 lg:pt-48 lg:pb-32 overflow-hidden bg-white">
      {/* Background Gradients */}
      <div className="absolute top-0 inset-x-0 h-full overflow-hidden z-0 pointer-events-none">
         <div className="absolute -top-[20%] -right-[10%] w-[100%] sm:w-[70%] h-[70%] bg-gradient-to-br from-primary-50/80 to-green-100/30 rounded-full mix-blend-multiply filter blur-3xl opacity-60"></div>
         <div className="absolute top-[10%] -left-[10%] w-[100%] sm:w-[60%] h-[60%] bg-gradient-to-tr from-emerald-50/80 to-teal-100/30 rounded-full mix-blend-multiply filter blur-3xl opacity-60"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10 text-center">
        
        {/* Badge - Updated Text */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-slate-200 text-slate-600 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-6 sm:mb-8 shadow-sm hover:shadow-md transition-shadow cursor-default backdrop-blur-sm bg-white/50">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary-500"></span>
          </span>
          Giải pháp Tự động hóa Tuyển dụng Tối ưu nhất
        </div>

        {/* Main Headline */}
        <h1 className="text-3xl sm:text-5xl md:text-7xl font-extrabold tracking-tight text-slate-900 mb-6 sm:mb-8 leading-[1.15] sm:leading-[1.1]">
          Hệ thống Quản lý Tuyển dụng (ATS) <br className="hidden sm:block" />
          trên <span className="text-primary-600 underline decoration-4 decoration-primary-200 underline-offset-4">Google Sheets</span>
        </h1>

        <p className="mt-4 sm:mt-8 max-w-3xl mx-auto text-base sm:text-xl text-slate-600 mb-8 sm:mb-10 leading-relaxed font-light px-2 sm:px-0">
          Giải pháp tinh gọn giúp doanh nghiệp Việt <strong className="font-semibold text-slate-900">tự động hóa 80%</strong> tác vụ thủ công. 
          <br className="hidden md:block"/>
          Dữ liệu được lưu trữ trên tài khoản Google của chính bạn - <span className="text-primary-600 font-semibold">An toàn tuyệt đối</span>.
        </p>

        {/* CTA Buttons - Stack on Mobile */}
        <div className="flex flex-col sm:flex-row justify-center items-center gap-3 sm:gap-4 mb-12 sm:mb-16 w-full max-w-md mx-auto sm:max-w-none">
          <a
            href={demoLink}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-8 py-4 bg-slate-900 text-white font-bold rounded-xl text-base sm:text-lg hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/20 hover:-translate-y-1 flex items-center justify-center gap-3 active:scale-95"
          >
            Sao chép Mẫu miễn phí
            <ArrowRight size={20} />
          </a>
          <a
            href="#pricing"
            className="w-full sm:w-auto px-8 py-4 bg-white text-slate-700 font-bold rounded-xl text-base sm:text-lg border border-slate-200 hover:bg-slate-50 transition-all hover:border-slate-300 shadow-sm active:bg-slate-100"
          >
            Xem bảng giá
          </a>
        </div>

        {/* REAL GOOGLE SHEETS EMBED WRAPPER */}
        <div className="relative mx-auto max-w-6xl px-0 sm:px-0 mt-8">
          <div className="rounded-xl sm:rounded-2xl bg-slate-900/5 p-1 sm:p-3 ring-1 ring-inset ring-slate-900/10 lg:-m-4 lg:rounded-3xl lg:p-4 backdrop-blur-3xl mx-2 sm:mx-0">
             <div className="relative w-full aspect-[4/5] sm:aspect-[16/9] lg:aspect-[16/8] rounded-lg sm:rounded-xl shadow-2xl overflow-hidden bg-white border border-slate-200">
                
                {/* Browser Toolbar Mockup */}
                <div className="hidden sm:flex h-8 bg-slate-50 border-b border-slate-200 items-center px-4 gap-2">
                   <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div>
                      <div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
                   </div>
                   <div className="flex-1 text-center text-[10px] text-slate-400 font-mono">docs.google.com/spreadsheets/u/0/ats-system</div>
                </div>

                <iframe 
                  src={embedLink} 
                  className="absolute top-0 sm:top-8 left-0 w-full h-full sm:h-[calc(100%-32px)]"
                  title="Google Sheets ATS Dashboard Demo"
                  loading="lazy"
                ></iframe>
                
                {/* Mobile Hint Overlay */}
                <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/60 to-transparent sm:hidden flex items-end justify-center pb-6 pointer-events-none">
                    <span className="text-white text-xs font-medium bg-black/40 px-4 py-2 rounded-full backdrop-blur-md border border-white/20 shadow-lg flex items-center gap-2">
                       <span className="animate-pulse">👆</span> Vuốt để xem báo cáo
                    </span>
                </div>
             </div>
          </div>
          <p className="mt-6 text-xs sm:text-sm text-slate-500 font-medium flex items-center justify-center gap-2 px-4 text-center">
            <CheckCircle size={14} className="text-green-500 shrink-0" />
            <span>Giao diện thực tế. Bấm "Sao chép Mẫu" để sở hữu file này.</span>
          </p>
        </div>

      </div>
    </div>
  );
};