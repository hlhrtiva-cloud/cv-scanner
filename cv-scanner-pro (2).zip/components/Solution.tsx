import React from 'react';
import { ShieldCheck, Server, RefreshCw, ArrowRight, ArrowDown, BrainCircuit } from 'lucide-react';

export const Solution: React.FC = () => {
  return (
    <section id="solution" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-20">
          <span className="text-primary-700 font-bold tracking-wider uppercase text-xs sm:text-sm mb-2 block">Giải pháp tối ưu</span>
          <h2 className="text-2xl sm:text-4xl font-bold text-slate-900 mb-4 sm:mb-6">
            Hệ sinh thái Tuyển dụng Khép kín
          </h2>
          <p className="text-base sm:text-lg text-slate-600 max-w-3xl mx-auto leading-relaxed px-2">
            Không bán phần mềm. Không giữ dữ liệu. <br className="hidden sm:block"/>
            Chúng tôi cung cấp <strong className="text-slate-900">công cụ thông minh</strong> chạy trực tiếp trên hạ tầng Google của bạn.
          </p>
        </div>

        {/* Workflow Diagram - Responsive */}
        <div className="bg-[#0f172a] rounded-2xl sm:rounded-3xl p-6 sm:p-16 mb-12 sm:mb-20 shadow-2xl relative overflow-hidden">
          
          <div className="relative z-10">
            <h3 className="text-white text-center font-bold text-xs sm:text-sm mb-10 sm:mb-16 uppercase tracking-widest inline-block w-full">
              <span className="border-b border-white/20 pb-2">Quy trình vận hành tự động</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6 sm:gap-8 items-center justify-items-center text-center max-w-5xl mx-auto">
              
              {/* Step 1: Drive */}
              <div className="flex flex-col items-center group w-full relative z-20">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-lg shadow-white/10 transition-transform duration-300 group-hover:scale-105">
                  <svg viewBox="0 0 87.3 78" className="w-10 h-10 sm:w-12 sm:h-12">
                    <path d="M6.6 66.85l3.85 6.65c.8 1.4 1.95 2.5 3.3 3.3l13.75-23.8h-27.5c0 1.55.4 3.1 1.2 4.5z" fill="#0066DA"/>
                    <path d="M43.65 25l-13.75-23.8c-1.35.8-2.5 1.9-3.3 3.3l-25.4 44a9.06 9.06 0 0 0 -1.2 4.5h27.5z" fill="#00AC47"/>
                    <path d="M73.55 76.8c1.35-.8 2.5-1.9 3.3-3.3l1.6-2.75 7.65-13.25c.8-1.4 1.2-2.95 1.2-4.5h-55l13.75 23.8z" fill="#EA4335"/>
                    <path d="M43.65 25l13.75 23.8-13.75 23.8h-27.5l13.75-23.8z" fill="#00832D"/>
                    <path d="M59.8 53.2l-16.15 27.8 29.9.05c1.55 0 3.1-.4 4.5-1.2l-18.25-31.6z" fill="#2684FC"/>
                    <path d="M73.4 26.5l-12.7-22c-1.35-.8-2.9-1.2-4.5-1.2h-30l15.75 27.2z" fill="#FFBA00"/>
                  </svg>
                </div>
                <h4 className="text-white font-bold text-base sm:text-lg mb-1 sm:mb-2">Google Drive</h4>
                <p className="text-slate-400 text-[10px] sm:text-xs font-medium">Nơi lưu trữ CV <br/>(Dữ liệu của bạn)</p>
              </div>

              {/* Arrow Mobile (Down) / Desktop (Right) */}
              <div className="w-full flex justify-center -my-2 sm:my-0 md:hidden z-10">
                 <ArrowDown className="text-slate-600 w-6 h-6 animate-bounce" />
              </div>
              <div className="hidden md:flex justify-center w-full">
                <ArrowRight className="text-slate-600 w-6 h-6" />
              </div>

              {/* Step 2: Generic AI */}
              <div className="flex flex-col items-center group w-full relative z-20">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-lg shadow-white/10 transition-transform duration-300 group-hover:scale-105 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 to-purple-600 opacity-10"></div>
                  <BrainCircuit className="w-12 h-12 sm:w-16 sm:h-16 text-indigo-600" />
                </div>
                <h4 className="text-white font-bold text-base sm:text-lg mb-1 sm:mb-2">Trí tuệ nhân tạo (AI)</h4>
                <p className="text-slate-400 text-[10px] sm:text-xs font-medium">Bộ xử lý thông minh <br/>(Phân tích & Chấm điểm)</p>
              </div>

              {/* Arrow Mobile (Down) / Desktop (Right) */}
               <div className="w-full flex justify-center -my-2 sm:my-0 md:hidden z-10">
                 <ArrowDown className="text-slate-600 w-6 h-6 animate-bounce delay-100" />
              </div>
              <div className="hidden md:flex justify-center w-full">
                <ArrowRight className="text-slate-600 w-6 h-6" />
              </div>

              {/* Step 3: Sheets */}
              <div className="flex flex-col items-center group w-full relative z-20">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-lg shadow-white/10 transition-transform duration-300 group-hover:scale-105">
                  <svg viewBox="0 0 87.3 78" className="w-10 h-10 sm:w-12 sm:h-12">
                     <path d="M53.5 0H8.7C6.3 0 4.3 2 4.3 4.3V22H0v34h4.3v17.7c0 2.3 2 4.3 4.3 4.3h44.8c2.3 0 4.3-2 4.3-4.3V4.3C57.8 2 55.8 0 53.5 0z" fill="#0F9D58"/>
                     <path d="M41.8 22H16.2V11h25.7v11zm0 13H16.2V24h25.7v11zm0 13H16.2V37h25.7v11zm0 13H16.2V50h25.7v11z" fill="white"/>
                  </svg>
                </div>
                <h4 className="text-white font-bold text-base sm:text-lg mb-1 sm:mb-2">Google Sheets</h4>
                <p className="text-slate-400 text-[10px] sm:text-xs font-medium">Dashboard quản trị <br/>(Báo cáo tức thì)</p>
              </div>
            </div>
          </div>
        </div>

        {/* Key Benefits - Stacked on Mobile */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-4 sm:mb-6 text-blue-700">
              <Server size={24} />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-2 sm:mb-3">100% Quyền Sở Hữu</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Dữ liệu ứng viên, lịch sử phỏng vấn nằm trên Google Drive/Sheets của bạn. Bạn không bị phụ thuộc vào nhà cung cấp.
            </p>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-50 rounded-lg flex items-center justify-center mb-4 sm:mb-6 text-green-700">
              <RefreshCw size={24} />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-2 sm:mb-3">Cập nhật Liên tục</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Chúng tôi liên tục cập nhật thuật toán AI và các tính năng mới. Hệ thống của bạn sẽ tự động thông minh hơn theo thời gian.
            </p>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-50 rounded-lg flex items-center justify-center mb-4 sm:mb-6 text-purple-700">
              <ShieldCheck size={24} />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-2 sm:mb-3">Bảo mật Tiêu chuẩn</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Thừa hưởng lớp bảo mật doanh nghiệp từ Google Workspace. Không lo ngại vấn đề an ninh mạng hay downtime server.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};