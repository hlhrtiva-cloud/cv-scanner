import React, { useState, useEffect } from 'react';

export const CtaFinal: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({ minutes: 14, seconds: 59 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds === 0) {
          if (prev.minutes === 0) return prev;
          return { minutes: prev.minutes - 1, seconds: 59 };
        }
        return { ...prev, seconds: prev.seconds - 1 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="cta" className="py-16 sm:py-20 bg-primary-600 text-white">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-2xl sm:text-4xl font-extrabold mb-4 sm:mb-6 leading-tight">Sẵn sàng tiết kiệm 80% thời gian tuyển dụng?</h2>
        <p className="text-lg sm:text-xl text-primary-100 mb-8 sm:mb-10">Dùng thử miễn phí - Không cần thẻ tín dụng</p>

        <div className="bg-white/10 backdrop-blur rounded-xl p-6 sm:p-8 mb-8 sm:mb-10 border border-white/20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 sm:gap-8">
             <div className="text-left w-full md:w-auto">
               <h3 className="text-lg sm:text-xl font-bold text-yellow-300 mb-2 sm:mb-3 text-center md:text-left">🎁 Ưu đãi đặc biệt</h3>
               <ul className="space-y-2 text-sm text-primary-50 bg-black/10 md:bg-transparent p-4 md:p-0 rounded-lg">
                 <li className="flex items-start gap-2"><span>•</span> <span>10 khách hàng đầu tiên: <strong>MIỄN PHÍ 3 tháng gói PRO</strong></span></li>
                 <li className="flex items-start gap-2"><span>•</span> <span>Tặng setup 1-1 với đội ngũ kỹ thuật</span></li>
                 <li className="flex items-start gap-2"><span>•</span> <span>Training miễn phí trọn đời</span></li>
               </ul>
             </div>
             
             {/* Mobile-optimized Timer */}
             <div className="flex flex-col items-center bg-white/10 md:bg-transparent p-4 rounded-xl w-full md:w-auto">
                <div className="text-xs font-semibold mb-2 text-primary-100 uppercase tracking-widest">Ưu đãi kết thúc sau</div>
                <div className="flex gap-2 text-3xl sm:text-2xl font-mono font-bold">
                   <div className="bg-white text-primary-600 px-3 py-2 rounded-lg shadow-lg min-w-[60px] text-center">{String(timeLeft.minutes).padStart(2, '0')}</div>
                   <span className="self-center pb-1">:</span>
                   <div className="bg-white text-primary-600 px-3 py-2 rounded-lg shadow-lg min-w-[60px] text-center">{String(timeLeft.seconds).padStart(2, '0')}</div>
                </div>
                <div className="mt-3 text-[10px] sm:text-xs font-bold text-red-300 animate-pulse bg-red-900/30 px-2 py-1 rounded-full">
                   🔥 Còn 7 chỗ cuối cùng
                </div>
             </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row justify-center gap-4 w-full sm:w-auto">
          <button className="w-full sm:w-auto px-8 py-4 bg-white text-primary-600 font-bold rounded-xl text-lg hover:bg-slate-100 transition-colors shadow-xl active:scale-95">
            Dùng thử miễn phí 20 CVs
          </button>
          <a href="https://zalo.me/0961128912" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-xl text-lg hover:bg-white/10 transition-colors active:scale-95">
            Liên hệ tư vấn
          </a>
        </div>

        <div className="mt-8 flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs sm:text-sm text-primary-200 opacity-80">
           <span className="flex items-center gap-1"><span className="text-green-300">✓</span> Setup 5 phút</span>
           <span className="flex items-center gap-1"><span className="text-green-300">✓</span> No-code 100%</span>
           <span className="flex items-center gap-1"><span className="text-green-300">✓</span> Support 24/7</span>
        </div>
      </div>
    </section>
  );
};