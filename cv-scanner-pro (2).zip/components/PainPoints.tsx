import React from 'react';
import { Clock, Mail, BarChart3, Lock } from 'lucide-react';

export const PainPoints: React.FC = () => {
  const points = [
    {
      icon: <Clock className="w-8 h-8 text-red-600" />,
      title: "Lãng phí nguồn lực",
      desc: "HR mất 3-4 giờ mỗi ngày cho các tác vụ thủ công lặp lại (Data Entry, lọc CV rác).",
      quote: "Chi phí ẩn cho nhân sự admin quá cao."
    },
    {
      icon: <Mail className="w-8 h-8 text-orange-600" />,
      title: "Quy trình rời rạc",
      desc: "Thông tin ứng viên nằm rải rác ở Email, Zalo, Excel cá nhân. Khó quản lý tập trung.",
      quote: "Khi nhân viên nghỉ việc, dữ liệu cũng mất theo."
    },
    {
      icon: <BarChart3 className="w-8 h-8 text-blue-600" />,
      title: "Thiếu dữ liệu ra quyết định",
      desc: "Không biết kênh tuyển dụng nào hiệu quả? Tỷ lệ chuyển đổi phễu tuyển dụng là bao nhiêu?",
      quote: "Quản lý bằng cảm tính thay vì số liệu thực."
    },
    {
      icon: <Lock className="w-8 h-8 text-slate-600" />,
      title: "Rủi ro bảo mật",
      desc: "Sử dụng phần mềm bên thứ 3 đồng nghĩa với việc giao phó dữ liệu ứng viên cho họ.",
      quote: "Lo ngại về việc rò rỉ data ứng viên tiềm năng."
    }
  ];

  return (
    <section className="py-16 sm:py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-4xl font-bold text-slate-900 leading-tight">
            Thách thức của Quản lý Tuyển dụng hiện đại
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 max-w-3xl mx-auto">
            Trong kỷ nguyên số, việc quản lý thủ công không chỉ tốn kém mà còn làm mất đi lợi thế cạnh tranh của doanh nghiệp.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {points.map((item, index) => (
            <div key={index} className="bg-white p-6 sm:p-8 rounded-xl shadow-sm border border-slate-200 hover:shadow-lg transition-all duration-300">
              <div className="mb-4 sm:mb-6 bg-slate-50 w-14 h-14 sm:w-16 sm:h-16 rounded-lg flex items-center justify-center border border-slate-100">
                {item.icon}
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2 sm:mb-3">{item.title}</h3>
              <p className="text-slate-600 mb-4 text-sm leading-relaxed">{item.desc}</p>
              <div className="pt-4 border-t border-slate-100 text-xs text-slate-500 italic font-medium">
                "{item.quote}"
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};