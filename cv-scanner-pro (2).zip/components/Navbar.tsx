import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'Tính năng', href: '#features' },
    { name: 'Lợi ích', href: '#solution' },
    { name: 'Bảng giá', href: '#pricing' },
    { name: 'Hướng dẫn', href: '#how-it-works' },
  ];

  const demoLink = "https://docs.google.com/spreadsheets/d/1X7cGtQU3sLYn5Qf5gXKxnREHXX_cgQWf_t6oFbgITQs/edit?gid=1780097193#gid=1780097193";

  return (
    <nav className="fixed w-full z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex-shrink-0 flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo(0,0)}>
            <div className="w-10 h-10 bg-gradient-to-br from-primary-700 to-primary-600 rounded-lg flex items-center justify-center text-white font-bold text-2xl shadow-lg">
              C
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-xl tracking-tight text-slate-900 leading-none">CV Scanner Pro</span>
              <span className="text-xs text-slate-500 font-medium tracking-wide">GIẢI PHÁP DOANH NGHIỆP</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-slate-600 hover:text-primary-700 font-medium text-sm uppercase tracking-wide transition-colors"
              >
                {link.name}
              </a>
            ))}
            <a
              href={demoLink}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-800 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5 text-sm"
            >
              Trải nghiệm Demo
            </a>
          </div>

          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-600 hover:text-slate-900 focus:outline-none"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 absolute w-full shadow-2xl">
          <div className="px-4 pt-2 pb-6 space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block px-4 py-4 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50 border-b border-slate-50 last:border-0"
              >
                {link.name}
              </a>
            ))}
            <div className="mt-6 px-3 pb-4">
               <a
                href={demoLink}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsOpen(false)}
                className="block w-full text-center bg-primary-700 text-white px-5 py-4 rounded-lg font-bold hover:bg-primary-800 transition-colors shadow-lg"
              >
                Trải nghiệm Demo ngay
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};