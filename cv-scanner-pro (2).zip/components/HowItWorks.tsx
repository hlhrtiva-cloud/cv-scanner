import React from 'react';
import { ExternalLink, HardDrive, PlayCircle } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const demoLink = "https://docs.google.com/spreadsheets/d/1X7cGtQU3sLYn5Qf5gXKxnREHXX_cgQWf_t6oFbgITQs/edit?gid=1780097193#gid=1780097193";

  return (
    <section id="how-it-works" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <span className="text-primary-700 font-bold tracking-wider uppercase text-xs sm:text-sm mb-2 block">Dễ dàng triển khai</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Setup hệ thống trong 5 phút</h2>
          <p className="mt-4 text-slate-600">Không cần kiến thức lập trình (No-code). Quy trình 3 bước đơn giản.</p>
        </div>

        <div className="relative grid grid-cols-1 md:grid-cols-3 gap-10 sm:gap-12">
          {/* Connecting line - Only visible on desktop */}
          <div className="hidden md:block absolute top-12 left-[16%] right-[16%] h-0.5 bg-slate-200 -z-10 border-t-2 border-dashed border-slate-300"></div>

          {/* Step 1 */}
          <div className="relative flex flex-col items-center text-center group">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full border-4 border-slate-100 flex items-center justify-center mb-4 sm:mb-6 group-hover:border-primary-200 transition-colors shadow-sm z-10">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 font-bold text-xl sm:text-2xl">1</div>
            </div>
            <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-slate-900">Sao chép Template</h3>
            <p className="text-slate-600 mb-4 sm:mb-6 text-sm px-2 sm:px-4">
              Click vào link bên dưới để tạo bản sao (Make a copy) Google Sheets về Drive của bạn.
            </p>
            <a 
              href={demoLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary-50 text-primary-700 rounded-lg text-sm font-bold hover:bg-primary-100 transition-colors border border-primary-200"
            >
              Mở Google Sheet <ExternalLink size={14} />
            </a>
          </div>

          {/* Step 2 */}
          <div className="relative flex flex-col items-center text-center group">
             {/* Mobile connector line vertical (optional, simpler without) */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full border-4 border-slate-100 flex items-center justify-center mb-4 sm:mb-6 group-hover:border-primary-200 transition-colors shadow-sm z-10">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-white border-2 border-slate-200 rounded-full flex items-center justify-center text-slate-600">
                  <HardDrive size={24} className="sm:w-7 sm:h-7" />
                </div>
            </div>
            <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-slate-900">Kết nối Drive</h3>
            <p className="text-slate-600 mb-4 sm:mb-6 text-sm px-2 sm:px-4">
              Trong Sheet, nhập ID folder chứa CV trên Google Drive của bạn. Hệ thống sẽ tự động nhận diện.
            </p>
            <div className="text-xs text-slate-500 font-medium bg-slate-50 px-3 py-1 rounded">
               ⏱️ Mất khoảng 2 phút
            </div>
          </div>

          {/* Step 3 */}
          <div className="relative flex flex-col items-center text-center group">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full border-4 border-slate-100 flex items-center justify-center mb-4 sm:mb-6 group-hover:border-primary-200 transition-colors shadow-sm z-10">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-green-50 border-2 border-green-100 rounded-full flex items-center justify-center text-green-600">
                   <PlayCircle size={24} className="sm:w-7 sm:h-7" />
                </div>
            </div>
            <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-slate-900">Kích hoạt Auto</h3>
            <p className="text-slate-600 mb-4 sm:mb-6 text-sm px-2 sm:px-4">
              Bấm nút "Start" trên Menu. AI sẽ bắt đầu quét, chấm điểm và báo cáo tự động.
            </p>
            <div className="text-xs text-green-600 font-bold bg-green-50 px-3 py-1 rounded border border-green-100">
               ✅ Ready to use
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};