import React from 'react';
import { Facebook, Linkedin, Mail, Phone, MapPin, Send } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 sm:pt-16 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-12 mb-12">
          
          {/* Brand Column */}
          <div className="col-span-1 lg:col-span-1 border-b border-slate-800 pb-8 md:border-0 md:pb-0">
            <div className="flex items-center gap-3 mb-4 sm:mb-6 text-white">
              <div className="w-10 h-10 bg-primary-700 rounded-lg flex items-center justify-center font-bold text-2xl shadow-lg shadow-primary-900/50">C</div>
              <div>
                <span className="font-bold text-xl block leading-none">CV Scanner Pro</span>
                <span className="text-[10px] text-slate-400 tracking-widest uppercase">Enterprise Solutions</span>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed mb-6 pr-4">
              Đối tác công nghệ tin cậy của doanh nghiệp Việt. Chúng tôi giúp bạn chuyển đổi số quy trình tuyển dụng đơn giản, hiệu quả và bảo mật.
            </p>
            <div className="flex space-x-4">
                <a href="https://www.facebook.com/profile.php?id=61570158981854" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center hover:bg-primary-600 hover:text-white transition-all hover:-translate-y-1"><Facebook size={20} /></a>
                <a href="https://www.linkedin.com/in/v%C5%A9-ho%C3%A0i-l%C3%A2n-51a773130/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all hover:-translate-y-1"><Linkedin size={20} /></a>
            </div>
          </div>
          
          {/* Contact Column */}
          <div>
            <h4 className="font-bold text-white mb-4 sm:mb-6 uppercase tracking-wider text-sm flex items-center gap-2">
                Liên hệ <span className="h-px w-8 bg-slate-700 block md:hidden"></span>
            </h4>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3 group">
                <div className="p-2 bg-slate-800 rounded group-hover:bg-primary-900/50 transition-colors">
                    <Phone size={16} className="text-primary-500" /> 
                </div>
                <div>
                  <div className="font-medium text-white">Hotline / Zalo</div>
                  <a href="https://zalo.me/0961128912" className="hover:text-primary-400 transition-colors font-mono">096 112 8912</a>
                </div>
              </li>
              <li className="flex items-start gap-3 group">
                 <div className="p-2 bg-slate-800 rounded group-hover:bg-primary-900/50 transition-colors">
                    <Mail size={16} className="text-primary-500" /> 
                 </div>
                <div>
                  <div className="font-medium text-white">Email</div>
                  <a href="mailto:phongnhansufindnet@gmail.com" className="hover:text-primary-400 transition-colors break-all">phongnhansufindnet@gmail.com</a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                 <div className="p-2 bg-slate-800 rounded">
                    <MapPin size={16} className="text-primary-500" /> 
                 </div>
                <span className="mt-1">Hà Nội, Việt Nam</span>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col">
            <h4 className="font-bold text-white mb-4 sm:mb-6 uppercase tracking-wider text-sm flex items-center gap-2">
                Sản phẩm <span className="h-px w-8 bg-slate-700 block md:hidden"></span>
            </h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#features" className="hover:text-primary-400 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-primary-500 rounded-full"></span>Tính năng AI</a></li>
              <li><a href="#solution" className="hover:text-primary-400 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-primary-500 rounded-full"></span>Quy trình vận hành</a></li>
              <li><a href="#pricing" className="hover:text-primary-400 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-primary-500 rounded-full"></span>Bảng giá Enterprise</a></li>
              <li><a href="https://docs.google.com/spreadsheets/d/1X7cGtQU3sLYn5Qf5gXKxnREHXX_cgQWf_t6oFbgITQs/edit?gid=1780097193#gid=1780097193" target="_blank" rel="noopener noreferrer" className="hover:text-primary-400 transition-colors flex items-center gap-2"><span className="w-1 h-1 bg-primary-500 rounded-full"></span>Demo Template</a></li>
            </ul>
          </div>

          {/* Newsletter/CTA */}
          <div>
             <h4 className="font-bold text-white mb-4 sm:mb-6 uppercase tracking-wider text-sm flex items-center gap-2">
                Tư vấn miễn phí <span className="h-px w-8 bg-slate-700 block md:hidden"></span>
             </h4>
             <p className="text-xs text-slate-500 mb-4">Để lại thông tin để nhận tài liệu tối ưu quy trình tuyển dụng 2025.</p>
             <div className="flex gap-2">
               <input type="email" placeholder="Email của bạn" className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2.5 w-full focus:outline-none focus:border-primary-500 transition-colors" />
               <button className="bg-primary-600 text-white rounded-lg px-4 hover:bg-primary-700 transition-colors shadow-lg shadow-primary-900/50">
                 <Send size={18} />
               </button>
             </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500 gap-4 md:gap-0">
          <div className="text-center md:text-left">© 2025 CV Scanner Pro. Developed by Vu Hoai Lan.</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-slate-300 transition-colors">Điều khoản sử dụng</a>
            <a href="#" className="hover:text-slate-300 transition-colors">Chính sách bảo mật</a>
          </div>
        </div>
      </div>
    </footer>
  );
};