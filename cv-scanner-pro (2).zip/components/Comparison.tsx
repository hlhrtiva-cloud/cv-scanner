import React from 'react';
import { Check, X, Minus } from 'lucide-react';

export const Comparison: React.FC = () => {
  return (
    <section id="comparison" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">Tại sao chọn CV Scanner Pro?</h2>
          <p className="text-xl text-slate-600">So sánh hiệu quả đầu tư (ROI) trực tiếp</p>
        </div>

        {/* Comparison Cards - Mobile Stacked, Desktop Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-center mb-24">
          
          {/* Competitor 1 */}
          <div className="bg-slate-50 rounded-2xl p-8 border border-slate-200 opacity-80 hover:opacity-100 transition-opacity">
            <h3 className="font-bold text-xl mb-2 text-slate-700">ATS Việt Nam Khác</h3>
            <p className="text-sm text-slate-500 mb-6 font-medium">(Các phần mềm thuê bao)</p>
            <ul className="space-y-4">
               <li className="flex items-start gap-3 text-slate-600">
                 <div className="mt-0.5 min-w-[20px]"><X className="w-5 h-5 text-red-500" /></div>
                 <span className="text-sm">Chi phí ~1-2 triệu/tháng</span>
               </li>
               <li className="flex items-start gap-3 text-slate-600">
                 <div className="mt-0.5 min-w-[20px]"><X className="w-5 h-5 text-red-500" /></div>
                 <span className="text-sm">Quá nhiều tính năng thừa</span>
               </li>
               <li className="flex items-start gap-3 text-slate-600">
                 <div className="mt-0.5 min-w-[20px]"><X className="w-5 h-5 text-red-500" /></div>
                 <span className="text-sm">Phụ thuộc server bên thứ 3</span>
               </li>
            </ul>
          </div>

          {/* OUR PRODUCT - Highlighted */}
          <div className="bg-white rounded-3xl p-8 lg:p-10 border-2 border-primary-500 shadow-2xl shadow-primary-900/10 relative transform md:scale-105 z-10 order-first md:order-none">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary-600 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wider shadow-lg">
              Lựa chọn số #1
            </div>
            <h3 className="font-extrabold text-2xl mb-2 text-slate-900">CV Scanner Pro</h3>
            <p className="text-sm text-primary-600 mb-8 font-bold">Giải pháp tối ưu cho SME</p>
            <ul className="space-y-5">
               <li className="flex items-start gap-3">
                 <div className="bg-green-100 p-1 rounded-full"><Check className="w-4 h-4 text-green-600" /></div>
                 <span className="text-base font-semibold text-slate-800">Chi phí chỉ 299k/tháng</span>
               </li>
               <li className="flex items-start gap-3">
                 <div className="bg-green-100 p-1 rounded-full"><Check className="w-4 h-4 text-green-600" /></div>
                 <span className="text-base font-semibold text-slate-800">Tự động hóa 80% công việc</span>
               </li>
               <li className="flex items-start gap-3">
                 <div className="bg-green-100 p-1 rounded-full"><Check className="w-4 h-4 text-green-600" /></div>
                 <span className="text-base font-semibold text-slate-800">100% Bảo mật trên Drive</span>
               </li>
               <li className="flex items-start gap-3">
                 <div className="bg-green-100 p-1 rounded-full"><Check className="w-4 h-4 text-green-600" /></div>
                 <span className="text-base font-semibold text-slate-800">Không cần đào tạo (No-code)</span>
               </li>
            </ul>
          </div>

          {/* Competitor 2 */}
          <div className="bg-slate-50 rounded-2xl p-8 border border-slate-200 opacity-80 hover:opacity-100 transition-opacity">
            <h3 className="font-bold text-xl mb-2 text-slate-700">Excel Thủ Công</h3>
            <p className="text-sm text-slate-500 mb-6 font-medium">(Làm bằng tay)</p>
            <ul className="space-y-4">
               <li className="flex items-start gap-3 text-slate-600">
                 <div className="mt-0.5 min-w-[20px]"><X className="w-5 h-5 text-red-500" /></div>
                 <span className="text-sm">Mất 20 giờ/tuần nhập liệu</span>
               </li>
               <li className="flex items-start gap-3 text-slate-600">
                 <div className="mt-0.5 min-w-[20px]"><X className="w-5 h-5 text-red-500" /></div>
                 <span className="text-sm">Dữ liệu rời rạc, khó tìm kiếm</span>
               </li>
               <li className="flex items-start gap-3 text-slate-600">
                 <div className="mt-0.5 min-w-[20px]"><X className="w-5 h-5 text-red-500" /></div>
                 <span className="text-sm">Không có báo cáo realtime</span>
               </li>
            </ul>
          </div>
        </div>

        {/* Cost Analysis Block */}
        <div className="bg-slate-900 rounded-3xl p-6 md:p-12 text-white relative overflow-hidden">
             {/* Decor */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary-600/20 rounded-full blur-[100px]"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/20 rounded-full blur-[100px]"></div>

            <h3 className="text-2xl md:text-3xl font-bold mb-10 text-center uppercase tracking-wide relative z-10">Bài toán tối ưu chi phí</h3>
            <div className="grid md:grid-cols-2 gap-8 md:gap-16 relative z-10">
                <div className="border-l-4 border-red-500 pl-6 py-2">
                    <h4 className="text-red-400 font-bold mb-2 uppercase text-sm tracking-wider">Làm thủ công (Lãng phí)</h4>
                    <div className="text-4xl font-mono font-bold text-white mb-2">~3.000.000 <span className="text-sm text-slate-400 font-sans font-normal">đ/tháng</span></div>
                    <ul className="text-slate-400 text-sm space-y-1">
                        <li>• Lương HR trung bình: 10-12 triệu/tháng</li>
                        <li>• Thời gian nhập liệu & lọc CV: ~1-2h/ngày</li>
                        <li>• Lãng phí: ~40 giờ làm việc/tháng</li>
                    </ul>
                </div>

                 <div className="border-l-4 border-primary-500 pl-6 py-2">
                    <h4 className="text-primary-400 font-bold mb-2 uppercase text-sm tracking-wider">Dùng CV Scanner Pro</h4>
                    <div className="text-4xl font-mono font-bold text-white mb-2">299.000 <span className="text-sm text-slate-400 font-sans font-normal">đ/tháng</span></div>
                     <ul className="text-slate-400 text-sm space-y-1">
                        <li>• Chi phí cố định cực thấp</li>
                        <li>• Tự động hóa 100% khâu nhập liệu</li>
                        <li>• HR tập trung vào phỏng vấn & văn hóa</li>
                    </ul>
                </div>
            </div>
            
            <div className="mt-12 text-center">
                <div className="inline-block px-6 py-3 bg-white/10 rounded-full backdrop-blur border border-white/20 text-sm font-semibold">
                    🚀 Tiết kiệm <span className="text-primary-400 text-lg">90%</span> chi phí vận hành cho phòng nhân sự
                </div>
            </div>
        </div>

      </div>
    </section>
  );
};